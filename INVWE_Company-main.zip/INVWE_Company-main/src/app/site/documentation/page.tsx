import DocumentationPage from "@/components/documentation/documentation-page"

export default function Page() {
  return <DocumentationPage />
}
